# SolidCraft Cycloidal Drive

A cycloidal speed reducer generator for [SolidCraft](https://github.com/tangency-labs/solidcraft), ported line for line from the Onshape FeatureScript "Cycloidal Drive Generator" by the same author. It builds the whole drive in one run: cycloidal discs, the eccentric shaft with its stepped races, the ring-gear housing, and the output pin carriers. Bearings are **not** generated — you add those separately (the layout and every bearing-sized feature respects the `disc_bearing_*`, `eccentric_bearing_*` and `housing_bearing_*` dimensions). Every step is an ordinary SolidCraft command — what lands on your timeline is editable features (sketches, extrudes, lofts, booleans, chamfers, fillets), not a mesh. It is not a mesh.

Everything is computed from the FeatureScript's equations inside a sandboxed WebAssembly plugin (`craft:plugin@0.1.0`, capability `commands@0.1`). It needs no files, no network and no clock.

## Install

You need a SolidCraft build that has the plugin host (the `commands@0.1` capability).

1. Download `solidcraft-cycloidal-<version>.zip` from the [latest release](../../releases/latest) or use the folder from this repository's `dist/solidcraft-cycloidal/`.
2. Unzip it into SolidCraft's plugins folder, so you end up with a `solidcraft-cycloidal` folder in it holding `plugin.json` and `plugin.wasm`:

| OS | Plugins folder |
|---|---|
| Windows | `%LOCALAPPDATA%\SolidCraft\plugins\` |
| macOS | `~/Library/Application Support/SolidCraft/plugins/` |
| Linux | `$XDG_DATA_HOME/solidcraft/plugins/` (usually `~/.local/share/solidcraft/plugins/`) |

3. Start SolidCraft. Preferences > Plugins lists it; listing never runs any code. Each run needs your approval of the exact package contents.

## Use

The plugin has a single entry, `make-cycloidal`. All sizes are millimetres. The drive is built on the chosen sketch plane, in one absolute frame, starting at `z = 0` (the back face of the back journal) and growing along the plane normal. Defaults reproduce the FeatureScript's dialog defaults, with two deliberate exceptions called out below.

| Entry | Effect | What it does |
|---|---|---|
| `make-cycloidal` | edit | Builds the whole drive, including the housing's cusp fillets (built into the bore profile — no second step needed) |

The entry declares a `ribbon` slot named `Cycloidal Drive`, so it appears in the **Plugins** ribbon tab labelled **Cycloidal Drive** (one group per plugin), and it is always also listed in the app-bar **Plugins** menu; the command reads **Cycloidal Drive**. Since v0.22 the dropdowns show friendly titles (`Pins (scalloped casing)`, `Shoulder screw`, …) via `oneOf` `{const, title}` — the values stored in parameters, scripts and `CycloidalDriveLastParams` are unchanged. When the build finishes, every sketch it made is hidden, and the bodies are moved into one component per body, named after it — `Housing`, `Back Shaft`, `Eccentric Shaft`, `Front Shaft`, `Cycloid disc 1..N`, `Back Output Carrier`, `Front Output Carrier`, plus `Back/Front Housing Bearing Holder` when the holders are built as separate parts. The housing is the grounded occurrence by default (grounded through `occurrence.ground`); all other bodies keep `z` as built, so the design is ready to use as an assembly.

The drive is wired up as a mechanism: `Back Shaft`/`Eccentric Shaft`/`Front Shaft` are coupled by a rigid group, the shaft rotates in the grounded housing about the main axis (joint `Shaft`), each disc rotates about its own race axis (joints `Disc 1..N`), and the carriers follow jointly on the main axis (joint `Output`). Motion links make the discs counter-rotate at `a05_ring_pin_count/(a05_ring_pin_count-1)` of the shaft — the exact cycloidal ratio for the profile's lobe count — and the output follows Disc 1 1:1, so the drive output rotates opposite to the input at ratio `a05_ring_pin_count-1`. Driving the `Shaft` joint (e.g. `joint.drive {"joint":"Shaft","value":180}`) counter-rotates the discs and the output exactly `180*a05_ring_pin_count/(a05_ring_pin_count-1)` degrees. `joint.list` reports no conflicts and no floating parts. The ON/OFF choices are dropdowns (`True`/`False`), so their state is always visible and saved as you pick them. The fields ship without pre-filled defaults. Leave one or more empty and the plugin applies your last run's settings (stored in the hidden `CycloidalDriveLastParams` parameter); a short, human-readable summary is also published as two text parameters — `CycloidalLastRun` (the headline geometry) and `CycloidalLastToggles` (which toggles were on: carriers, pin holes, inner lips, holder styles + lip toggles, alignment hole, ground choice, ring-pin style, output style) — read them in Parameters to see exactly what the design was built with. on the very first run it uses the built-in defaults. Hover any blank field to read exactly that: *"Empty = your last value."* Type a value to override just that parameter (and from then on). Explicitly passed values always win.

Re-running the plugin in a design it already built **erases the previous drive before rebuilding** (it stores the ids of everything it created in the `CycloidalDriveIds` parameter), so changing a parameter and re-running applies it in place instead of stacking a second gearbox on top of the old one.

`a09_ground_output_carriers` (default false) flips the roles: the **output pin carriers are grounded** and the **housing is the output**, rotating at `shaft/a05_ring_pin_count` in the shaft's direction. Same geometry, same discs, same reducer ratio — the difference is only which occurrence is fixed. (By default the carriers are the output, as in the FeatureScript.) The Housing occurrence is un-grounded; both carriers are grounded via `occurrence.ground`.

`make-cycloidal` parameters — all optional, defaults shown, grouped by category in the order they appear in the dialog:

### Layout & ring gear
| Parameter | Default | Meaning |
|---|---|---|
| `a01_sketch_plane` | `XY` | `XY`, `XZ` or `YZ`; the drive is built on that plane, from the origin, along its normal |
| `a02_housing_diameter` | 95 | Housing outer diameter |
| `a03_ring_pin_pitch_diameter` | 80 | Pitch circle of the ring pins |
| `a04_ring_pin_diameter` | 5 | Ring pin diameter |
| `a05_ring_pin_count` | 30 | Number of ring pins (≥ 3) |
| `a06_ring_pin_style` | `integrated` | `integrated` = pins protrude from the casing; `pins` = scalloped casing (halved casing) |
| `a09_ground_output_carriers` | false | `false` (default): housing fixed, carriers output. `true`: carriers fixed, housing is the output (rotates at `shaft/a05_ring_pin_count` around the axis) |
| `a07_housing_gap_lower` / `a08_housing_gap_upper` | 1.5 / 1.5 | Axial gaps between the discs and the housing/journals |

### Discs
| Parameter | Default | Meaning |
|---|---|---|
| `a10_disc_count` | 2 | Number of phase-shifted discs (1–4) |
| `a11_disc_width` | 7 | Axial disc width |
| `a12_disc_gap` | 1.5 | Axial gap between discs |
| `a13_eccentricity` | 1 | Shaft race a13_eccentricity; discs are offset by this, rotated 360°/`a10_disc_count` per disc |
| `a14_resolution` | 50 | Disc profile sampling (`a05_ring_pin_count` × `a14_resolution`, capped at 480 fit points) |

### Output pins & carriers
| Parameter | Default | Meaning |
|---|---|---|
| `a36_add_back_output_carrier` / `a27_add_front_output_carrier` | true | Output pin carriers, nested inside the housing bearing span |
| `a37_add_back_output_pin_holes` / `a28_add_front_output_pin_holes` | true | Cut the output pin (or screw shank) holes in the back / front carrier |
| `a41_output_pin_pitch_diameter` | 50 | Output pin circle |
| `a40_output_pin_diameter` | 10 | Output pin diameter (disc holes are `a40_output_pin_diameter` + 2e) |
| `a42_output_pin_count` | 6 | Number of output pins |
| `a38_add_back_carrier_inner_lip` / `a29_add_front_carrier_inner_lip` | true / true | Annular rib inside each carrier bore face-covering the outer race of the shaft journal bearing (per side toggle; the outer lip / flange is always built) |

### Holders, chamfers and output pin bearings (0.27)

- **Separate holders with no lip**: when a side is `separate` **and** its lip toggle is off, the housing keeps its full length (as in integrated mode); the holder now covers exactly the same seat as the integrated side but exists as its own body. Only when the lip is on does the housing get shortened there (and the holder cover the freed space).
- **Holder bore chamfer**: the open (outer) rim of each holder bore gets a 0.5 mm chamfer; the casing-side rim (where the bearing seats) stays sharp.
- **Carrier hole chamfers**: every output-pin hole in both carriers gets a 0.5 mm chamfer on both mouths (where holes actually reach the rim — grazed holes are skipped).
- **Output pin bearings** (`a53_output_pin_bearings`, shoulder-screw mode only): the screws become the output pins with a bearing inserted in each screw. The disc holes become exactly the bearing OD (no eccentricity clearance — the bearing rolls in the hole). Provide the dims (`a54_output_pin_bearing_outer_diameter`, `a55_output_pin_bearing_inner_diameter`, `a56_output_pin_bearing_width`) and the plugin generates **spacer sleeves** (one component per sleeve, `Output Pin Spacer 1…N`, one sleeve per screw per disc gap) so each bearing sits centred in its disc hole. Spacer dimensions: bore = bearing ID + 0.5 mm, OD = (OD + ID)/2 − 0.25 mm (bearing OD minus one radial race width estimate, minus clearance). The carriers keep shank-sized holes; the counterbore/pocket logic is unchanged.

### Housing & housing bearing holders
| Parameter | Default | Meaning |
|---|---|---|
| `a33_add_back_housing_bearing_holder` | true | Extra housing wall section over the **back** housing-bearing seat (carrier span) |
| `a35_add_back_housing_bearing_holder_lip` | true | Lip at the holder base (edge adjacent to the casing) that face-covers the outer race of the **back** housing bearing. Uncheck to omit |
| `a34_housing_bearing_back_holder_style` | `integrated` | `integrated` = holder merged into the `Housing` body — the housing is shortened by the lip thickness on that side when the lip is on (drive keeps the same overall length; the holder+lip extrude as one piece into it). If the lip is off, the housing keeps its full length in both styles — the holder then exists as a separate body over the seat without shortening anything. `separate` = own part/component, rigidly coupled (`housing-holder-rigid`) |
| `a24_add_front_housing_bearing_holder` | true | Same, for the **front** seat |
| `a26_add_front_housing_bearing_holder_lip` | true | Lip at the holder base face-covering the outer race of the **front** housing bearing. Uncheck to omit |
| `a25_housing_bearing_front_holder_style` | `integrated` | Same, independent per side |

### Output pins & screws
| Parameter | Default | Meaning |
|---|---|---|
| `a39_output_pin_style` | `pins` | The construction driving the output: `pins` (plain pins, `a40_output_pin_diameter`), `shoulder_screw` (a screw driving the output, head + shank, head counterbored into the carriers) |
| `a40_output_pin_diameter` | 10 | Diameter of the pins (used when `a39_output_pin_style` = `pins`); disc holes are `a40_output_pin_diameter` + 2×a13_eccentricity |
| `a43_screw_shank_diameter` | 6 | Shoulder screw shank diameter; the discs and carriers get shank-sized holes (used when `a39_output_pin_style` = `shoulder_screw`) |
| `a44_screw_shank_length` | 25 | Shoulder screw shank length — in shoulder-screw mode the carrier on each selected `a47_screw_head_counterbore` side is NOT drilled through: it gets a blind pocket from the flange's outer face whose bottom sits exactly `a44_screw_shank_length` from that face (counterbore for the head for `a46_screw_head_length`, continuing at shank diameter to `a44_screw_shank_length`; clamped to the flange+tube wall). The disc holes stay through-all. With `both` both carriers get the pocket |
| `a45_screw_head_diameter` | 10 | Shoulder screw head diameter — sets the counterbore diameter |
| `a46_screw_head_length` | 5 | Shoulder screw head length — sets the counterbore depth (clamped to the flange) |
| `a47_screw_head_counterbore` | `front` | `front`, `back` or `both`; the head counterbore, cut from the flange's outer face |

### Bearings (not generated — dimensions only)
| Parameter | Default | Meaning |
|---|---|---|
| `a15_disc_bearing_outer_diameter` / `a16_disc_bearing_inner_diameter` / `a17_disc_bearing_width` | 32 / 20 / 7 | Disc bearing OD / ID / width |
| `a18_eccentric_bearing_outer_diameter` / `a19_eccentric_bearing_inner_diameter` / `a20_eccentric_bearing_width` | 32 / 20 / 7 | Journal bearing OD / ID / width |
| (published variables) | | The housing bearing settings publish as `HbFOD`, `HbFID`, `HbFW` (front) and `HbBOD`, `HbBID`, `HbBW` (back) document variables |
| `a21_housing_bearing_front_outer_diameter` / `a22_housing_bearing_front_inner_diameter` / `a23_housing_bearing_front_width` | **72 / 64** / 7 | Front housing bearing OD / ID / width. **Not** the FeatureScript's 32 / 20 — see deviations |
| `a30_housing_bearing_back_outer_diameter` / `a31_housing_bearing_back_inner_diameter` / `a32_housing_bearing_back_width` | **72 / 64** / 7 | Back housing bearing OD / ID / width (same as front by default) |

### Alignment hole
| Parameter | Default | Meaning |
|---|---|---|
| `a48_add_alignment_hole` | false | Extra hole in a gap of the output pin circle |
| `a49_alignment_hole_diameter` / `a50_alignment_hole_orientation` | 2.5 / `vertical` | Alignment hole size and which grid arm |
| `a51_invert_holes_x` / `a52_invert_holes_y` | false / false | Mirror the alignment hole across the X / Y axis |

Validation (all hard errors, nothing is built on failure): `a02_housing_diameter` must exceed **both** `a21_housing_bearing_front_outer_diameter` and `a30_housing_bearing_back_outer_diameter` by at least 2 mm when a holder is enabled (the holder wall carries the bearing); bearings require `OD > ID` for each of the three bearing families; with a carrier enabled, both `a22_housing_bearing_front_inner_diameter` and `a31_housing_bearing_back_inner_diameter` must exceed `a18_eccentric_bearing_outer_diameter` (the carrier tube is bored to clear the journal bearing — the tube would delete itself), and the output pin holes must sit fully on each carrier tube (`a41_output_pin_pitch_diameter/2 + pin_diameter/2 ≤ both housing bearing inner radii/2); `a05_ring_pin_count ≥ 3`; `a10_disc_count` 1–4 (host budget).

The reply of `make-cycloidal` lists the body names (`Back Shaft`, `Eccentric Shaft`, `Front Shaft`, `Cycloid disc 1..N`, `Housing`, `Back Output Carrier`, `Front Output Carrier`, plus the separate holders if enabled), the drive's front z, the housing depth, how many document variables were published, how many sketches were hidden (`sketches_hidden`), the components created (`components`) and the joints/links created (`joints`). It publishes the FeatureScript's settings as document variables with their exact names (`HD`, `RpPD`, `RpD`, `RpN`, `e`, `DW`, `DN`, `Dd`, `DdhLow`, `DdhUpper`, `DbOD`, `DbID`, `DbW`, `EsbOD`, `EsbID`, `EsbW`, `HbFOD`, `HbFID`, `HbFW`, `HbBOD`, `HbBID`, `HbBW`, `OpPD`, `OpD`, `OpN`), so later features can reference them with `#Name` syntax. Existing parameters are updated atomically; missing ones are added. Re-running overwrites them in place.

From the command line, with a `solidcraft-cli` that has the plugin host:

```
solidcraft-cli run inspect.json --results        # [{"command":"plugin.inspect","params":{"path":"<plugins>/solidcraft-cycloidal"}}]
solidcraft-cli run make.json --results --save cycloidal.sc
```

where `make.json` is

```json
[{"command": "plugin.run", "params": {
  "path": "<plugins>/solidcraft-cycloidal",
  "approval": "<the approval hash inspect gave you>",
  "entry": "make-cycloidal",
  "params": {}}}]
```

The build fuses body creation and union into the same operation wherever it can — shaft segments, ring pins, housing holders, carrier flanges and inner lips join straight into their target in one extrude — so the timeline holds fewer features and rebuilds faster. `a14_resolution` applies only to the disc profile sampling (the cycloid lobes); everything else circular is built with true circles.

## What it builds

- **Cycloidal discs**: the true prolate cycloid, arc-length resampled and drawn as one periodic spline through ≤ 480 fit points, extruded, bored with the output pin holes (`a40_output_pin_diameter` + 2×a13_eccentricity) and the disc bearing bore. Disc phase = `360°/a10_disc_count` per disc; bearing bores are concentric with each disc's own position on its race.
- **Bearings are not generated**: the carriers are sized to nest inside the housing bearing span; the sleeve/shaft/disc bores and races are sized by the bearing dimensions; the flange radius is computed from the housing bearing's ball-pitch geometry (`(HbOD + HbID)/4 − 0.4·(HbOD − HbID)/8`) so the lip covers the inner race. Generate your own bearings and drop them into the races/bores sized by the published variables.
- **Eccentric shaft**: back journal → eccentric races (one cylinder per race, lofted transition segments between them, shouldered lofts into and out of the eccentric section) → front journal, journal tips chamfered, race tips chamfered, merged into `Back Shaft`, `Eccentric Shaft`, `Front Shaft`.
- **Ring-gear housing**: an annulus (outer shell + filleted inner wall); the default `integrated` unions the pin cylinders into it (the pins protrude from the casing into the cavity), while `pins` cuts pin-sized bites from it (scalloped lobe teeth on the wall). The cusp edges where a pin circle meets the large-radius arc come out at the same coordinates either way.
- **Cusp fillets**: the housing's inner wall is drawn as a wire of circle arcs — at every cusp, a radius-`0.9 × maxLobeRootFillet` blend tangent to both the large-radius arc and the pin circle. The fillet is extruded with the wall, so there is no second step and no separate entry. One period of the arc chain (four arcs) is drawn for pin 0 and patterned around the pin count.
- **Output pin carriers**: stepped tube nested inside the housing bearing span + an outer lip/flange covering the inner race, with the bore (to clear the journal bearing) and the pin holes, then merged into one body. The optional **inner lip** (`a38_add_back_carrier_inner_lip` / `a29_add_front_carrier_inner_lip`, default true each) is an annular rib in the tube bore that face-covers the **outer race of the shaft journal bearing** — same z interval as the outer lip (the flange), merged into the carrier. Shoulder-screw mode adds the head counterbore on the selected carrier(s).
- **Housing bearing holders**: an extra section of the housing wall over each housing-bearing seat — annulus between the bore (the front/back `housing_bearing_*_outer_diameter` — the bearing presses in) and the housing OD, spanning the same z span as each side's carrier, plus a **lip** at the base (the edge adjacent to the casing) that face-covers the outer race of the housing bearing (radius `(HbOD + HbID)/4 + 0.4·(HbOD − HbID)/8` of the respective side). Back and front are independent toggles, each with its own **style** and its own **lip toggle** (`a34_housing_bearing_back_holder_style` / `a25_housing_bearing_front_holder_style` and `a35_add_back_housing_bearing_holder_lip` / `a26_add_front_housing_bearing_holder_lip`). `integrated` (default) merges the holder into the `Housing` body — the housing is shortened by the lip thickness on that side **when the lip is on** (drive keeps the same overall length; the holder+lip extrude as one piece into it), or kept full when the lip is off. `separate` keeps the holder as its own part/components (`Back/Front Housing Bearing Holder`), rigidly coupled (`housing-holder-rigid`) — and with the lip off it covers exactly the same seat as the integrated case without shortening the housing.
- **On completion**: every sketch in the design is hidden (`browser.visibility` with `folder: "sketches"`, hides all of them — construction geometry is useless after the drive is extruded); the bodies are moved into one component per body (`component.from_bodies`) — named after their bodies, `Housing` first so it is the grounded occurrence. Separate holders get their own components and are rigidly coupled to the housing via a rigid group. The drive itself is wired: shaft rigid group, `Shaft` revolute in the grounded housing, per-disc `Disc N` revolute on each race axis (phase-shifted by the a13_eccentricity), `Output` revolute in the housing, carriers rigidly coupled, and motion links — `Shaft→Disc N` at `−a05_ring_pin_count/(a05_ring_pin_count−1)` and `Disc 1→Output` at 1.0 — so `joint.drive` on the `Shaft` joint exercises the whole reducer. With `a09_ground_output_carriers` on, the carriers are grounded instead and the housing is the output (links `Shaft→Disc N` at −1 once per disc, `Shaft→Output` at `1/a05_ring_pin_count`); tangency on the pin ring then drags the housing around at `shaft/a05_ring_pin_count`. Bearings you generate separately go into their own components the same way.

## Deviations from the FeatureScript

Kept as close as the plugin ABI and SMLib allow; these are the differences, all deliberate:

- **Bearings are not generated** (unlike the FeatureScript, which builds simplified deep-groove ball bearings in one body per bearing). The bearing *dimensions* still drive everything they must: the disc race width and z layout, the races, the disc and journal bores, the carrier's tube, bore and flange (including the flange radius from the housing bearing's ball-pitch geometry), the chamfer clamps and the carrier nesting checks. Add your own bearings against them.
- **Housing bearing defaults**: `housing_bearing_front_*` and `housing_bearing_back_*` default to **72 / 64 / 7 mm**, not the FeatureScript's 32 / 20 / 7. With the FS defaults the carrier tube and flange are completely deleted by their own bore cuts (SolidCraft removes consumed bodies), and the output pin holes fall entirely outside any carrier material — the FS dialog defaults produce an incoherent drive, in Onshape as well. Pick any values that satisfy the validation rules to bring the bearings back down to what you need.
- **The cusp fillet is built into the bore profile, not applied as a 3-D fillet.** Filleting the 2×`a05_ring_pin_count` cusp edges of a finished housing costs ~17 s of kernel time; instead, the housing's inner wall is drawn as a wire of circle arcs with a radius-`0.9 × maxLobeRootFillet` tangent blend at every cusp (the same 0.9 margin the FeatureScript's theoretical limit needs under SMLib), and the annulus is extruded once. The blend arcs are tangent to both the large-radius arc and the pin circle, so the vertical cusp edges come out rounded; `sketch.pattern.circular` replicates the four template arcs around the pin count, and the whole housing costs ~141 commands.
- **The disc rim (B-spline outer boundary) is not chamfered.** SMLib cannot chamfer a portable B-rep spline edge; the discs get their deburring chamfers on the hole circles only.
- **`a10_disc_count` is capped at 4** (FeatureScript: 20). The host runs at most 256 commands per entry call, and each disc needs its own features.
- **The disc profile is capped at 480 fit points** (FeatureScript: `a05_ring_pin_count × a14_resolution`). `sketch.spline.fit_point` takes at most 500 points; the curve is resampled at the same arc-length positions.
- **Ring pins and output pin holes are drawn once and patterned** (`sketch.pattern.circular`) instead of N circles.
- **Document variables** are published with `parameters.add` / `parameters.change` (the FeatureScript uses `setVariable`); existing parameters are updated atomically. Values re-evaluate on every recompute and new features can use `#Name`.
- **Journal and race chamfers** are clamped to the journal size (0.5 mm / 30° and 0.3 mm defaults are kept for sane inputs); the host rolls back the whole run if a chamfer is impossible, so the FeatureScript's unconditional 0.5 / 0.3 mm are scaled down for tiny journals instead of failing.
- **SolidCraft has no units in command JSON** (a JSON number is millimetres); unit-aware FeatureScript values are plain numbers here.
- **A failed command rolls back the whole call** (host rule) — unlike the FeatureScript, the plugin cannot catch-and-continue a failing operation, so every optional operation is constructed to succeed.
- **Sketches are hidden on completion and the bodies moved into components.** The build hides all its sketches (the FeatureScript leaves its sketches visible) and then runs `component.from_bodies` on the eight bodies, creating one component per body named after it — `Housing` first, which is the grounded occurrence. Timeline order: hide, then components, then the joints, then the reply.
- **The drive is wired as a mechanism** (`joint.*` commands): rigid groups for the shaft bodies and for the two carriers, revolute joints `Shaft` (in the grounded housing), `Disc 1..N` (on each disc's own race axis, offset by the a13_eccentricity) and `Output` (in the housing), plus motion links `Shaft→Disc 1..N` at ratio `−a05_ring_pin_count/(a05_ring_pin_count−1)` (the disc's absolute spin counter-rotates at one lobe per shaft revolution) and `Disc 1→Output` at 1.0. Driving `Shaft` spins the whole reducer as one mechanism.
- Entry names: `make-cycloidal` (single entry).
- **Disc profile points** are emitted as a periodic spline (no duplicated end point).

## Tests

`cargo test` checks the math (defaults validate, the profile's radial band and point cap, the fillet bound, the gap snapping, the cusp-fillet tangency and continuity) plus a host-budget test that runs the whole build against a mock kernel and fails if more than 256 commands would be emitted. `tests/cli_test.py` runs the built plugin through `solidcraft-cli`, saves each design and measures the result: body count, body names, closedness, bounding boxes, housing z span, variable publication, disc identity, the `.sc` reopen, the built-in cusp fillets (integrated volume above the sharp-cusp reference), the style delta between the two ring-gear variants, the hidden sketches, the components (one per body, `Housing` grounded), the joint list (zero conflicts, links at exactly −30/29 and 1.0) and a live drive of the mechanism (shaft 180° → output moves −180·30/29°), plus a `a09_ground_output_carriers` run (housing un-grounded, carriers grounded, housing rotates at shaft/a05_ring_pin_count).

```
./build.sh
SOLIDCRAFT_CLI=/path/to/solidcraft-cli python3 tests/cli_test.py
```

## Build

You need Rust with the `wasm32-unknown-unknown` target and [`wasm-tools`](https://github.com/bytecodealliance/wasm-tools). `./build.sh` builds the core module, wraps it as a component and leaves the package in `dist/solidcraft-cycloidal/`. The WIT in `wit/` is a copy of SolidCraft's `craft:plugin@0.1.0`.

## License

MIT, see [LICENSE](LICENSE). The cycloidal disc equations and the housing fillet derivation are ported from the author's FeatureScript "Cycloidal Drive Generator".
