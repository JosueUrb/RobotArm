# GT2 Pulley

A GT2 (2 mm pitch) curvilinear pulley generator for [SolidCraft](https://github.com/tangency-labs/solidcraft), ported **feature-for-feature** from the FeatureScript **GT2 Pulley** (which the author wrote for Onshape). The design lands on your timeline as ordinary editable features — no meshes, no baked geometry.

## Install

**Preferences ▸ Plugins ▸ Install plugin…** and pick `solidcraft-gt2-pulley-0.1.0.zip` (or use the release `./dist` zip), or `plugin.install` it. One component per run, named after the body (`GT2 Pulley`).

## Use

**Plugins** ribbon tab ▸ **GT2 Pulley** (a `ribbon` slot named after the plugin, item shown with the plug badge), or the Plugins menu. The ON/OFF choices are dropdowns (`True`/`False`), so their state is always visible and saved as you pick them. The fields ship without pre-filled defaults. Leave one or more empty and the plugin applies your last run's settings (stored in the hidden `GT2PulleyLastParams` parameter); a readable summary is published as `GT2PulleyLastRun` — read it in Parameters to see what the design was built with. On the very first run it uses the built-in defaults. Hover any blank field to read exactly that: *"Empty = your last value."* Type a value to override just that parameter (and from then on). Explicitly passed values always win.

Re-running the plugin in a design it already built **erases the previous pulley before rebuilding** (it tracks ids in `GT2PulleyBuildIds`), so changing a parameter and re-running applies it in place instead of stacking a second pulley on top of the old one. Running the plugin back-to-back with identical parameters returns the cached output with `"unchanged": true, "skipped": true`.

| Parameter | Default | Meaning |
|---|---|---|
| `a01_sketch_plane` | `XY` | `XY`, `XZ` or `YZ`; the pulley is built on that plane with the rotation axis on its normal |
| `a02_sketch_only` | `false` | Build just the construction sketch (groove outline, bore, screw circle), no booleaned body |
| `a03_teeth` | 20 | Number of GT2 teeth (8–120) |
| `a04_pulley_width` | 7 mm | Pulley width (axial) |
| `a05_bore_shape` | `round` | `round` or `dcut` (D-cut with one flat) — the D-cut dropdown sends `dcut` |
| `a06_bore_diameter` | 5 mm | Bore diameter |
| `a07_dflat_depth` | 0.5 mm | Flat cut depth into the bore, measured from the bore's top tangent (`dcut` only; must be smaller than the bore diameter) |
| `a08_mirror` | `false` | Flip the whole construction across the sketch plane (flanges and counterbores end up on the other side) |
| `a09_add_back_flange` | `true` | Side guide flange on the back face |
| `a10_add_front_flange` | `true` | Side guide flange on the front face |
| `a11_flange_thickness` | 1.0 mm | Thickness of each side guide flange |
| `a12_add_holes` | `true` | Hub screw pattern |
| `a13_screw_circle_pitch_diameter` | 10 mm | Circle the screw holes sit on |
| `a14_screw_count` | 4 | Number of hub holes |
| `a15_screw_diameter` | 3 mm | Hub hole diameter = screw shank size |
| `a16_screw_holes` | `true` | Shoulder screw mode: shank-sized through holes plus a head counterbore |
| `a17_head_diameter` | 5.5 mm | Counterbore diameter (screw mode only) |
| `a18_head_length` | 4 mm | Counterbore depth, measured from the back flange face (screw mode only) |

## What it builds

One component `GT2 Pulley` (body `GT2 Pulley`), built from: (1) an analytic-cylinder blank; (2) the curvilinear GT2 groove profile, sketched per tooth and cut from the blank (with the FeatureScript's 4-sample land arcs between grooves); (3) independently toggleable side guide flanges (OD = pulley OD + 4.5 mm); (4) analytic-cylinder bore, with an optional D-cut flat; (5) hub holes (through) with optional head counterbores rooted at the back flange face; (6) all construction sketches hidden on exit, occurrence explicitly un-grounded (the assembly grounds it).

The groove points ship **exactly** as the FeatureScript traced them (including the ~1.3e-4 mm asymmetry at `gy = 0.037218`).

## Deltas vs the FeatureScript (all forced or agreed)

- **`mergeIntoFeature` dropped** — merging into an existing feature needs a face pick in the host, and plugin input is plain JSON (there is no selection parameter kind). The pulley always builds on the sketch plane. (The FeatureScript's face pick also made the back flange flush with that face; without it, mirror is the way to choose the flange side.)
- **Sketch plane = XY/XZ/YZ** — the same reason; there is no face/plane pick in plugin input. The pulley starts at the origin.
- **Sketch-only outline decimates to ≤ 500 points** — the host's `sketch.spline.fit_point` accepts at most 500 points, so at tooth counts above 20 the construction sketch thins the perimeter evenly (the part's grooves are cut per-tooth and are always exact).
- **Two safety validations added** (the FeatureScript builds nonsense silently): `a06_bore_diameter` must be smaller than the pulley OD, and `a07_dflat_depth` must be smaller than the bore diameter.
- Shoulder screw counterbores are rooted at the **back flange face**, measured inward — exactly like the FeatureScript. If both flanges are off, `a18_head_length` roots at the ring's back face; if only the front flange is on, the counterbores root `a11_flange_thickness` behind the ring's back face (the FeatureScript's own quirk, kept verbatim — set a back flange on if you want the screws seated on it).
- **No ground added** — the pulley is a free insert until the assembly constrains it (the assembly grounds it).

## Tests

`SOLIDCRAFT_CLI=/path/to/solidcraft-cli tests/cli_test.py` — builds default, permuted, both-flange-off, D-cut, mirror, sketch-only and cached-run cases; verifies body counts, component creation, grounding state, in-place rebuild, and the last-used/cached paths.

## Build

`bash build.sh` → `dist/solidcraft-gt2-pulley`. MIT licensed; includes `wit/plugin.wit`.
