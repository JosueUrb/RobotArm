# Ball Bearing

A ball bearing generator for [SolidCraft](https://github.com/tangency-labs/solidcraft), ported **feature-for-feature** from the hand-written FeatureScript **Ball bearing** (which the author wrote for Onshape). The design lands on your timeline as ordinary editable features (sketches, lines, arcs, revolves, extrudes, a circular pattern and booleans) — no meshes, no baked geometry.

**Placement (SolidCraft 0.43)** — the entry declares a `ribbon` slot named `Ball Bearing`, so it appears in the **Plugins** ribbon tab labelled **Ball Bearing** (one group per plugin, item shown with the plugin’s name and plug badge), and it is always also listed in the app-bar **Plugins** menu.

Default build (the FeatureScript's default design, with the agreed parameter changes):

| Parameter | Default | Meaning |
|---|---|---|
| `a02_inner_diameter` | 8.875 mm | **True bore ID** — the inner race is a hollow sleeve. The ball circle is centred between bore and OD: `a = (a02_inner_diameter + a03_outer_diameter)/4`, so both race walls come out equal and the balls/cage sit in the middle |
| `a03_outer_diameter` | 60 mm | outside diameter |
| `a04_width` | 8 mm | bearing a04_width (axial) |
| `a05_balls_diameter` | 4.05 mm | ball diameter |
| `a07_gap` ("margin") | 0.025 mm | ball-to-groove radial clearance (groove radius = ball radius + a07_gap) |
| `a08_slot_width` | 1.0 mm | width of each of the two snap slots flanking every ball (0 = no slots) |
| `a09_slot_offset` | 2.0 mm | radial offset of the snap slots from the ball seat radius |
| `a06_balls_count` | 0 (automatic) | 0 computes the automatic odd count (≥ 3); any value in [4, 100] overrides it |
| `a01_sketch_plane` | XY | XY, XZ or YZ; the bearing is built on that plane with the rotation axis on its normal |

The ball count is computed as the largest **odd** number whose neighbouring pocket spheres keep at least **two ball diameters** of cage material between them, i.e. `chord = 2·a·sin(π/n) ≥ 2·rc + 2·a05_balls_diameter` with `rc = a05_balls_diameter/2 + a07_gap + 0.25`, clamped to [3, 99]. Odd counts spread the load more evenly. The example/default settings resolve to **7 balls**. Set `a06_balls_count` to any value in [4, 100] to override it (0 = automatic). The count in effect is published as the `BbN` document parameter.

Bodies produced:

- **Inner Race** — a revolved sleeve: bore + deep-groove ball race (two 45° flanks, tangent arcs, exact FeatureScript profile).
- **Outer Race** — a revolved ring with the deep-groove ball race on its bore (same tangent-arc construction).
- **Cage** — a one-piece annulus ("ring") revolved from `z = -a04_width/2 + 0.5 mm` to `z = a05_balls_diameter/4` (the cage is recessed 0.5 mm on each face vs the races — 1 mm shorter overall, exactly what the author asked — so the race faces read as the parting faces), plus one roofed post per ball (sector between the balls, intersected with a 45° gable prism along the bisector), merged into the ring, with one **ball pocket** sphere cut per ball and the two **snap slots** the FeatureScript specifies — one on each side of every ball, width `a08_slot_width` (default 1 mm) at the offset `a09_slot_offset` (default 2 mm from the ball seat radius), `BD/8..ZCAP` tall, swept towards the axis by 3 mm and patterned around the axis. Set `a08_slot_width = 0` to build a cage without slots.
- **Balls** — the actual ball bodies: one Ø`a05_balls_diameter` sphere per ball, placed on the pitch circle (ball 0 on +X, spacing `2π/n`). All ball bodies live in a single **Balls** component (the races and the cage are each their own component, as before).

Features:

- **Sketch plane support** — build the bearing on `XY`, `XZ` or `YZ` (default `XY`).
- **Automatically scaled rim chamfers** — both races get small chamfers on the bore / outer-diameter rims (top and bottom faces), sized from the ball diameter.
- **Blank dialog, your settings as defaults** — the fields ship without pre-filled defaults. Leave one or more empty and the plugin applies your last run's settings (stored in the hidden `BearingLastParams` document parameter); a short, human-readable summary of the last run is also published as the `BearingLastRun` text parameter — read it in Parameters to see what the design was built with. on the very first run it uses the built-in defaults. Hover any blank field to read exactly that: *"Empty = your last value."* Type a value to override just that parameter (and from then on). Values passed explicitly always win.
- Re-running the plugin in the same design erases the previous build (tracked through the `BearingBuildIds` document parameter) and rebuilds in place — parameter edits don't stack duplicate bearings.
- All sketches are hidden on exit; one component per body (plus the shared **Balls** component for all ball bodies). Three coaxial revolute joints are created — **`Shaft`** (Outer Race → Inner Race, revolute), **`Cage`** (Outer Race → Cage, trailing at the exact rolling cage ratio `(a − a05_balls_diameter/2) / 2a ≈ 0.441`) and **`Balls`** (Outer Race → Balls, tied 1:1 to the cage) — with **no ground**: `component.from_bodies` would ground the first occurrence by default, so every occurrence is explicitly un-grounded. Ground the bearing in the assembly (the assembly constrains it), then drive `Shaft` (e.g. `joint.drive {"joint":"Shaft","value":180}`); the cage and balls follow at their linked ratios.
- Derived values are republished as document parameters (`BoID`, `BoOD`, `BW`, `BbD`, `BbN`, `Bg`) so downstream sketches can reference them.
- Materials: races and balls **Steel**, cage **ABS Plastic** with the **ABS - Blue** appearance (editable afterwards).

Deliberate deltas vs the FeatureScript (all agreed with the author):

1. **Seal path removed entirely** — no seal parameters, features or sketches (the script's `BearingSeal` and the whole seal/groove/mirror tree).
2. **Ball count computed automatically** instead of a required parameter (largest odd number keeping ≥ two ball diameters between neighbouring pockets; `a06_balls_count` overrides it, 0 = automatic; the example/default settings give 7 balls).
3. **`a02_inner_diameter` is the true bore ID** (not the ball circle; the ball circle is derived) and `a03_outer_diameter` is the OD. Everything else in the script is unchanged.
4. **`a01_sketch_plane` and the auto-scaled chamfers** are additive conveniences; the FeatureScript only knows the XY plane and cuts no chamfers.

Not carried over from the FeatureScript (host limitations):

- The two **mate connectors** on the inner race (`Connector1`/`Connector2` in the script) — the host has no mate-connector command. In their place the plugin creates the assembly joints listed above (`Shaft`/`Cage`/`Balls`). To position or reference the bearing in the GUI, insert it from the part palette and constrain the races by face or origin.
- The script's pocket spheres are revolved profiles there; here they are true spheres — same result.
- Both race walls are equal by construction (the ball circle is derived as the midpoint between bore and outer diameter: `a = (a02_inner_diameter + a03_outer_diameter)/4`); the balls and the cage always sit exactly in the middle. Choose any bore; the whole geometry adapts.
